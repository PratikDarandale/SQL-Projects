create database superstore;

use superstore;

select * from indian_pincodes_mapping;
select * from offline_mobile_sales;
  
 /*1. Find the total and the average sale price (Revenue/Units) for each brand*/
 
SELECT brand,sum(Revenue/units) as total_sale_price,
round(avg(Revenue/units),2) as AVG_sale_price
FROM offline_mobile_sales 
group by brand;

/*Q2.2. Find the total revenue and units sold for each product*/
select brand,sum(revenue) as Total_revenue,product,sum(units) as UNITS_sole
FROM offline_mobile_sales
GROUP BY product;


/*Q3.Write a query to find the state wise revenue and its overall share (Revenue of
that state/Total revenue) including all mobile brands*/

select p.state,s.revenue, concat(round(s.revenue/sum(s.revenue)*100),'%') as share 
from offline_mobile_sales s 
left join Indian_pincodes_mapping p
on p.pincode=S.pincode
group by p.state;

/*Q.4.Find the top product with most sales in Metro region*/

SELECT o.product,o.revenue,m.city_tier FROM indian_pincodes_mapping m
JOIN offline_mobile_sales o
ON m.pincode = o.Pincode
WHERE m.city_tier = 'Metro'
GROUP BY o.product
ORDER BY o.revenue desc;  

/*Q.5.Find the states where Vicky Smart Phone are selling more than Katrina Slim
Phones*/

select a.state,b.units, b.brand,a.units,a.brand from
(select sum(units) as units,brand,state from indian_pincodes_mapping m 
join offline_mobile_sales o 
on m.pincode=o.pincode
where brand='Katrina Slim Phones'
group by state) as a
right join 
( select sum(units)as units,brand,state from indian_pincodes_mapping m
join offline_mobile_sales o 
on m.pincode=o.Pincode 
where Brand ='Vicky Smart Phone'
group by state) as b on a.state = b.state
where a.units < b.units;

/*Q6.Display the top contributing cities in North region in descending order of units
sold for Vicky Smart Phone*/
SELECT m.city,m.zone,o.units,o.brand FROM indian_pincodes_mapping m
INNER JOIN offline_mobile_sales o
ON m.pincode=o.pincode 
where m.zone ='North' and o.brand ='Vicky Smart Phone'
group by city
order by units desc ;

/*Q7.What is the pincode coverage of the offline retailer in each state?*/

select distinct(o.pincode)/count(o.pincode) as Pincode_coverge, m.state, sum(o.Revenue/o.units) as sales
FROM indian_pincodes_mapping m
INNER JOIN offline_mobile_sales o 
ON m.pincode= o.Pincode
group by state 
Having sales >1;

/*Q.8.Write a query to get the average selling price (Revenue/Units) across city tier
individually for both the brands. After getting the output, check if Metro's average
selling price for each brand is higher than Tier 3 and other? This will verify
whether metro customer buys a high end mobile phone compared to a tier 1 or
tier 3 customer*/

#FOR brand katrina slim phones 
select city_tier, average_selling_price,brand from 
(select round(avg(o.revenue/o.units)) as average_selling_price, m.city_tier, o.Brand from indian_pincodes_mapping m
join offline_mobile_sales o
ON o.pincode=m.pincode 
where brand ='Katrina Slim Phones'
group by city_tier) as a 
where city_tier in ('Metro','tier 3 & Others');

#FOR brand vicky smart phone
select city_tier,average_selling_price,brand FROM 
(select round(avg(o.revenue/o.units)) as average_selling_price, m.city_tier,o.Brand FROM indian_pincodes_mapping m
JOIN offline_mobile_sales o
ON o.pincode = m.pincode
WHERE brand ='Vicky Smart Phone' 
GROUP BY city_tier) as a
where city_tier in ('Metro','Tier 3 & Others');

/*Q9.Write a query to find sales details of all pincodes ordered by revenue in
descending order*/

select * from offline_mobile_sales
group by pincode
order by revenue DESC;

/*Q10.Using SQL date functions categorize August month into 4 week periods ( 1-7:
week 1, 8-14: week 2 and so forth). After doing this check if after 15th August,
the sales increased due to good discounts on Independence day sale*/

SELECT STR_TO_DATE(Date,'%y/%m/%d')as dateupdated FROM offline_mobile_sales;
 select Revenue, date_updated,(revenue/units) as sales,
 case when date_updated between '2021-08-01' and '2021-08-07' then 'week 1'
  when date_updated between '2021-08-08' and '2021-08-014' then 'week 2'
  when date_updated between '2021-08-15' and '2021-08-21' then 'week 3'
 when date_updated between '2021-08-022' and '2021-08-28' then 'week 4'
 end as August_month FROM (select *, STR_TO_DATE(date, '%m/%d/%y') as date_updated from offline_mobile_sales) b
 GROUP BY August_month;
