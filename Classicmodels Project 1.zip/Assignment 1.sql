use classicmodels;
/*Q.1. Find the customers whose “state” code is not filled and display only their full name and
contact number*/

SELECT CustomerName,Phone FROM customers
where state is null ;

/*Q.2.Find the product names for each of the orders in “Orderdetails” table*/

SELECT a.*,b.productname FROM orderdetails a
JOIN products b 
ON a.productCode=b.productcode;

/*Q.3.Using the “Payments” table, find out the total amount spent by each customer ID*/

SELECT customernumber,sum(amount) as Total_amount_spend FROM payments 
group by customerNumber;

SELECT * FROM payments; 

/* Q.4. Find out the number of customers from each country*/

SELECT COUNTRY,COUNT(customernumber) as NO_of_customers FROM customers 
group by country
order by country ASC ;

/*Q.5.Find out the amount of sales driven by each sales representative*/

select a.salesrepemployeenumber , sum(b.amount) as amount_sales_by_representative 
FROM customers as a
JOIN payments b
ON a.customerNumber=b.customerNumber
group by a. salesRepEmployeeNumber; 

/*Q.6. Find out the total number of quantity ordered per each order*/

select ordernumber,sum(quantityordered) as total_quantity_ordered FROM orderdetails 
group by ordernumber;

/*Q7. Find out the total number of quantity ordered per each product ID*/

select b.productcode ,sum(a.quantityordered) as total_quantity_order
FROM orderdetails a
JOIN products b 
ON a. productcode = b. productcode
group by b.productCode; 

/*Q.8. Find out the total number of orders made where the order value is over 7000 INR*/

select a.ordernumber,b.amount From orders a 
JOIN payments b
On a.customerNumber=b.customernumber 
where amount > 7000;

/* Q.9.List the customer names for those who their names are starting with “A”*/

select customername FROM customers
where customerName Like 'A%';

/* Q.10. Find the difference between the order date and the shipped date */

select orderdate,shippeddate, datediff(shippeddate,orderdate) 
as DATE_diff
FROM orders;

/*Q 11. Find out the profit for each product on the basis on buy price and sell price and find the
overall profit for all the inventory in stock*/

select quantityInstock,buyprice,MSRP,productname,round(MSRP-buyprice) as profit,
round((MSRP-buyprice)*quantityInstock) as Profit_ofall_invetory
FROM products;

/*Q.12. Find the profit for each product line and also see the inventory in stock*/

select productline,sum(MSRP-buyprice) as profit,quantityInstock From products group by productline;

/*Q.13.Create a view that maps the customers and their payments, ignore fileds that has greater
than 30% null values in it*/ 
create table customer_payment as select p.customerNumber,contactfirstname,customername,phone,addressline1,city,state,postalcode,
country,salesrepemployenumber,paymentdate,amount,checknumber FROM payment p
left join customers as c on p.customernumber =c.customernumber;

select 100.0 * sum(case when customersnumber is null then 1 else 0 end) / count(*) as customernumber_present,
 100.0 * sum(case when customername is null then 1 else 0 end) / count(*) as customername_present,
 100.0 * sum(case when contactlastname is null then 1 else 0 end) / count(*) as contactlastname_present,
 100.0 * sum(case when contactfirstname is null then 1 else 0 end) / count(*) as contactfirstname_present,
 100.0 * sum(case when phone is null then 1 else 0 end) / count(*) as phone_present,
 100.0 * sum(case when city is null then 1 else 0 end) / count(*) as city_present,
100.0 * sum(case when state is null then 1 else 0 end) / count(*) as state_present,
100.0 * sum(case when postalcode is null then 1 else 0 end) / count(*) as postalcode_present,
100.0 * sum(case when country is null then 1 else 0 end) / count(*) as country_present,
100.0 * sum(case when salesrepemployenumber is null then 1 else 0 end) / count(*) as salesrepemployenumber_present,
100.0 * sum(case when creditlimit is null then 1 else 0 end) / count(*) as creditlimit_present,
100.0 * sum(case when checknumber is null then 1 else 0 end) / count(*) as checknumber_present,
100.0 * sum(case when paymentdate is null then 1 else 0 end) / count(*) as paymentdate_present,
100.0 * sum(case when amount is null then 1 else 0 end) / count(*) as amount_present
FROM customer_payment;

### result by removing columns that has more than 30% null values
create view new_view as
select p.customerNumber,customername ,contactlastname,contactfirstname,phone,addressline1,
city,postalcode,country,salesrepemployenumber,creditlimit,checknumber,paymentdate,amount
FROM payments as p left join customers as c on p. customerNumber=c.customerNumber;

select *from new_view;

select *from customers;

/*Q.14.Check if the overall purchase value has exceeded the credit limit set for them*/

select c.customername,p.amount,c.creditlimit FROM customers c
JOIN payments p
on c.customerNumber =p.customerNumber 
WHERE p.amount> c.creditLimit; 

/*Q.15. Find the top performing sales agent, revenue generated and total number of customers for
each of them individually*/

Select salesRepEmployeeNumber,e.firstname,e.lastname,sum(p.amount) as revenue_genrated,count(c.customernumber) as no_of_customers,
 row_number() over(order by sum(p.amount)DESC,count(c.customernumber)DESC) as rnk
FROM employees e
inner join customers c on e.employeeNumber=c.salesRepEmployeeNumber 
join payments p 
on c.customerNumber=p.customernumber 
group by e.employeeNumber;




